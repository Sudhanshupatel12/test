# Shadow Gate Runner Easy Solution

## Short Answer

Every installation has its own flag:

```text
TEAMCTF{dyn_<seed_hex>_frida_or_trace}
```

`seed_hex` is the 16-byte runtime seed as 32 lowercase hex characters.

The mini-game is optional. Winning it only reveals the intended hint:

```text
Hint: the real value is a 16-byte runtime seed. Hook DynamicVault.current() or NativeGate.arm().
```

Use one of the methods below.

## 1. Static Route: APK + App Data

This is not APK-only static solving. The APK alone does not contain the seed. This route pulls the app's private preference file and unmasks the seed offline.

Install and open the APK once so the seed is created. Then run:

```bash
adb shell run-as com.shadow.gaterunner cat shared_prefs/shadow_state.xml
```

Copy the value of `sealed_runtime`, then run:

```python
import base64
import re

xml = """PASTE shadow_state.xml HERE"""
sealed = re.search(r'name="sealed_runtime">([^<]+)', xml).group(1)
data = bytearray(base64.b64decode(sealed))

def java_hash(text):
    h = 0
    for ch in text:
        h = (31 * h + ord(ch)) & 0xffffffff
    return h

def rol32(value, shift):
    return ((value << shift) | (value >> (32 - shift))) & 0xffffffff

mix = java_hash("com.shadow.gaterunner") ^ 0x53475221
for i in range(len(data)):
    mix = rol32((mix + i * 0x45d9f3b) & 0xffffffff, 5) ^ 0x7f4a7c15
    data[i] ^= (mix ^ (mix >> 11)) & 0xff

h = data.hex()
print("TEAMCTF{dyn_" + h + "_frida_or_trace}")
```

Submit the printed flag after tapping **Arm runtime gate**.

## 2. Java Hook Route

Hook the Java method that returns the live seed.

Save as `solve-java.js`:

```javascript
Java.perform(function () {
  const Vault = Java.use("com.shadow.gaterunner.DynamicVault");
  const current = Vault.current.overload("android.content.Context");

  function hex(seed) {
    let out = "";
    for (let i = 0; i < seed.length; i++) {
      let b = seed[i];
      if (b < 0) b += 256;
      out += ("0" + b.toString(16)).slice(-2);
    }
    return out;
  }

  current.implementation = function (context) {
    const seed = current.call(Vault, context);
    const h = hex(seed);
    console.log("[flag] TEAMCTF{dyn_" + h + "_frida_or_trace}");
    return seed;
  };
});
```

Run:

```bash
frida -U -f com.shadow.gaterunner -l solve-java.js
```

Resume the app, win the game or bypass the UI, tap **Arm runtime gate**, and copy the printed flag.

## 3. JNI Hook Route

Hook the native method call. `NativeGate.arm(byte[] seed, long tick)` passes the seed into JNI before native code verifies anything.

Save as `solve-jni.js`:

```javascript
Java.perform(function () {
  const Gate = Java.use("com.shadow.gaterunner.NativeGate");
  const arm = Gate.arm.overload("[B", "long");

  function hex(seed) {
    let out = "";
    for (let i = 0; i < seed.length; i++) {
      let b = seed[i];
      if (b < 0) b += 256;
      out += ("0" + b.toString(16)).slice(-2);
    }
    return out;
  }

  arm.implementation = function (seed, tick) {
    const h = hex(seed);
    console.log("[flag] TEAMCTF{dyn_" + h + "_frida_or_trace}");
    return arm.call(Gate, seed, tick);
  };
});
```

Run:

```bash
frida -U -f com.shadow.gaterunner -l solve_jni.js
```

Tap **Arm runtime gate** and use the printed flag.

## Native Export Name

If using lower-level native tooling, look for:

```text
Java_com_shadow_gaterunner_NativeGate_arm
```

Arguments are `JNIEnv*`, `jclass`, `jbyteArray seed`, and `jlong tick`. Dump the `jbyteArray`, convert it to hex, and wrap it in the flag format.











So the JADX/static solve idea is:
Find DynamicVault.current().
See it reads sealed_runtime from shared_prefs/shadow_state.xml.
See mask() is reversible because XOR is used.
Pull shadow_state.xml from the installed app.
Base64-decode sealed_runtime.
Run the same mask() logic again to recover the original seed.
Put the seed hex into:
TEAMCTF{dyn_<seed_hex>_frida_or_trace}